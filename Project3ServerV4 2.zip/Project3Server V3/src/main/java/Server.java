import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Objects;
import java.util.function.Consumer;
//import static java.io.FileDescriptor.out;

import javafx.application.Platform;
import javafx.scene.control.ListView;
/*
 * Clicker: A: I really get it    B: No idea what you are talking about
 * C: kind of following
 */

public class Server{
	ArrayList<ClientThread> clients = new ArrayList<ClientThread>();
	ArrayList<String> userNames = new ArrayList<>();
	TheServer server;
	private Consumer<Serializable> callback;
	String userName;
	
	Server(Consumer<Serializable> call){
		callback = call;
		server = new TheServer();
		server.start();
	}
	
	
	public class TheServer extends Thread{
		
		public void run() {
		
			try(ServerSocket mysocket = new ServerSocket(5555);){
		    System.out.println("Server is waiting for a client!");
		  
			
		    while(true) {
				ClientThread c = new ClientThread(mysocket.accept());

				// MOVE THIS TO SOMEWHERE ELSE
//				callback.accept("client has connected to server: " + "client #");
				/////////////////////////////

				clients.add(c);
				System.out.println("This is c: " + c);
				c.start();
			    }
			}//end of try
				catch(Exception e) {
					callback.accept("Server socket did not launch");
				}
			}//end of while
		}
	

		class ClientThread extends Thread{
			Socket connection;
			ObjectInputStream in;
			ObjectOutputStream out;
			Boolean userExists;

			// lets see if not having this is okay
//			Message message = new Message();

			ClientThread(Socket s){
				this.connection = s;
			}
			
			public void updateClients(Message message) {
				for(int i = 0; i < clients.size(); i++) {
					ClientThread t = clients.get(i);
					try {
					//t.out.reset();
//					 t.out.writeObject(message.textMessage);
					 t.out.writeObject(message);
					}
					catch(Exception e) {}
				}

				//FIGURE OUT A WAY TO UPDATE THE CLIENTS USERNAMESLIST WITH SERVER USERNAMES LIST
				// send a msg object from server to the client?
				// how is that possible?
//				for(int j = 0; j < userNames.size(); j++){
//
//				}
			}
			
			public void run(){
				try {
					in = new ObjectInputStream(connection.getInputStream());
					out = new ObjectOutputStream(connection.getOutputStream());
					connection.setTcpNoDelay(true);	
				}
				catch(Exception e) {
					System.out.println("Streams not open");
				}

//				updateClients("new client on server: client #");
				System.out.println("new client on server");

				 while(true) {
					    try {
							// waits until the button is pressed again
							System.out.println("INSIDE THE TRY STATEMENT");
					    	Message data = (Message) in.readObject();

							if(data.userName != null) {
								System.out.println("USERNAME: " + data.userName);
								for (int i = 0; i < userNames.size(); i++) {
									if (data.userName.equals(userNames.get(i))) {
										System.out.println("THERE IS A USER THAT IS EXISTING ALREADY IN THE LIST");
										data.userExists = true;
										break;
									} else {
										System.out.println("the username is unique");
										data.userExists = false;
									}
								}


								for (int i = 0; i < userNames.size(); i++) {
									System.out.println("USERNAMES IN LIST: " + i + " " + userNames.get(i));
								}

								// MOVING THE .ACCEPT THING HERE TESTING

								// if the user does not already exist then we want to add the user to the list
								if (data.userExists == false) {
									callback.accept("client has connected to server with User Name: " + data.userName);
									userNames.add(data.userName);
								}

								for (int i = 0; i < userNames.size(); i++) {
									data.userNameList.add(userNames.get(i));
								}
								userName = data.userName;
							}

							updateClients(data);

							System.out.println("Sending data!");
								/////////////////////
//							this.send(data);
								////////////////////


//							// loop goes through clientThreads
//							ClientThread client = new ClientThread(connection);
//							client.send(data);

							// UPDATING THE STUFF FOR THE GUI
					    	callback.accept(userName +" sent: " + data.textMessage);
							
							// UPDATING THE SCREEN FOR THE CLIENTS
//					    	updateClients("client #"+" said: "+data);
					    	
					    	}
					    catch(Exception e) {
							e.printStackTrace();
					    	callback.accept("OOOOPPs...Something wrong with the socket from client: "  + "....closing down!");
//					    	updateClients("Client #"+ " has left the server!");
							for(int i = 0; i < userNames.size(); i++){
								if(Objects.equals(userName, userNames.get(i))){
									userNames.remove(i);
									System.out.println("REMOVING THIS NAME: " + userNames.get(i));
									break;
								}
							}
					    	clients.remove(this);
					    	break;
					    }
					}
				}//end of run


			public void send(Message data) {
				try {
					out.writeObject(data);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
		}//end of client thread
}


	
	

	
