
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import javafx.scene.control.ChoiceBox;

public class GuiClient extends Application{
	TextField c1;
	Button b1;
	HashMap<String, Scene> sceneMap;
	VBox clientBox;
	Client clientConnection;
	Boolean welcomeScreen = true;

	ListView<String> listItems2;

	ListView<Button> chatNames = new ListView<>();
	ListView<String> usersList;
	ListView<String> chatScreen = new ListView<>();

	ArrayList<ListView> listOfChatScreens = new ArrayList<>();

	Message msg = new Message();

	String userName;
	String currentChatName;
	String userNameToSend2;
	
	
	public static void main(String[] args) {
		launch(args);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		clientConnection = new Client(data->{
				Platform.runLater(()->{

					msg = (Message) data;

					if(((Message) data).textMessage != null) {
						chatScreen.getItems().add(((Message) data).textMessage);
					}

					if(welcomeScreen == true) {
						if (msg.userName != null) {
							if (msg.userExists == false) {
								welcomeScreen = false;
								sceneMap.put("client", ActiveChatsScreen(primaryStage, sceneMap));
								primaryStage.setScene(sceneMap.get("client"));
							} else {
								Alert alert = new Alert(Alert.AlertType.WARNING);
								alert.setTitle("Username Taken!");
								alert.setContentText("The Username has already been taken, please choose a different Username");
								alert.showAndWait();
								welcomeScreen = true;
							}
						}
					}

					ObservableList<String> names = FXCollections.observableArrayList(msg.userNameList);
					usersList = new ListView<>(names);
			});
		});

		// starting the connection
		clientConnection.start();

		listItems2 = new ListView<String>();
		
		c1 = new TextField();
		b1 = new Button("Send");

		// SENDING THE TEXT MESSAGE TO THE SERVER
		
		sceneMap = new HashMap<String, Scene>();

		sceneMap.put("client",  welcomeScreen(primaryStage, sceneMap));


		primaryStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent t) {
                Platform.exit();
                System.exit(0);
            }
        });

		primaryStage.setScene(sceneMap.get("client"));
		primaryStage.setTitle("Client");
		primaryStage.setResizable(false);
		primaryStage.show();
	}

	public Scene welcomeScreen(Stage primaryStage, HashMap<String, Scene> sceneMap) {
		VBox welcomeScreenBox;
		HBox usernamePrompt;
		TextField inputUsername;
		Text title, enterUsername;
		Button startChattingButton;
		Image backgroundChatImage;

		// initializing the texts to their values
		title = new Text("WELCOME TO TALKS!");
		startChattingButton = new Button("Start Chatting!");
		enterUsername = new Text("Enter Username: ");
		inputUsername = new TextField();

		// initializing the HBox and VBox values
		usernamePrompt = new HBox(10, enterUsername, inputUsername);
		welcomeScreenBox = new VBox(30, usernamePrompt, startChattingButton);
		BorderPane pane = new BorderPane();

		// creating the background with the borderpane
		backgroundChatImage = new Image("two_peeps_talking.png");
		BackgroundSize size = new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, false, false, true, false);
		Background background = new Background(new BackgroundImage(backgroundChatImage, BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER, size));
		pane.setBackground(background);

		// setting the alignments of all the elements
		pane.setTop(title);
		BorderPane.setAlignment(title, Pos.TOP_CENTER);
		pane.setBottom(welcomeScreenBox);
		welcomeScreenBox.setAlignment(Pos.BOTTOM_CENTER);
		startChattingButton.setAlignment(Pos.BOTTOM_CENTER);
		usernamePrompt.setAlignment(Pos.CENTER);
		enterUsername.setTextAlignment(TextAlignment.CENTER);
		pane.setPadding(new Insets(75));

		// setting the font sizes, font weight, and font of the text elements
		enterUsername.setFont(Font.font("Josefin Sans", FontWeight.NORMAL, 18));
		title.setFont(Font.font("Josefin Sans", FontWeight.BOLD, 30));
		inputUsername.setMinWidth(100);
		startChattingButton.setMinWidth(150);
		startChattingButton.setMinHeight(25);
		startChattingButton.setFont(Font.font("Josefine Sans", FontWeight.NORMAL, 18));
		startChattingButton.setStyle("-fx-background-color: #93D6FB");

		// handle what happens when there is nothing inside the text field
		startChattingButton.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent actionEvent) {

				msg.userName = inputUsername.getText();
				userName = inputUsername.getText();

				clientConnection.send(msg);

				inputUsername.clear();
			}
		});

		return new Scene(pane, 500, 700);
	}

	public Scene ActiveChatsScreen(Stage primaryStage, HashMap<String, Scene> sceneMap){
		Text newChatMsg, noChatMsg;
		Image personIcon, plusIcon;
		Button viewUsers, createNewChat;
		ImageView personIconView, plusIconView;
		HBox createNewChatIcons, bannerIcons;

		// initializing the elements
		newChatMsg = new Text("Create New Chat");
		noChatMsg = new Text("No Active chats! Create a new chat\nto get the conversation going");
		personIcon = new Image("png_gruopchat.png");
		plusIcon = new Image("icon_plus_proj3.png");
		viewUsers = new Button();
		createNewChat = new Button();
		personIconView = new ImageView(personIcon);
		plusIconView = new ImageView(plusIcon);
		viewUsers.setGraphic(personIconView);
		createNewChat.setGraphic(plusIconView);
		createNewChatIcons = new HBox(10, newChatMsg, createNewChat);
		createNewChatIcons.setAlignment(Pos.CENTER);
		bannerIcons = new HBox(275, viewUsers, createNewChatIcons);
		bannerIcons.setAlignment(Pos.CENTER);

		// styling the top with a banner
		Rectangle banner = new Rectangle(500, 50);
		banner.setFill(Color.rgb(187, 217, 173));

		// adding elements to the banner
		StackPane bannerElements = new StackPane();
		bannerElements.getChildren().addAll(banner, bannerIcons);

		// editing the images to fit the screen
		personIconView.setPreserveRatio(true);
		personIconView.setFitHeight(25);
		personIconView.setFitWidth(25);
		plusIconView.setPreserveRatio(true);
		plusIconView.setFitHeight(25);
		plusIconView.setFitHeight(25);

		// creating border pane and aligning + setting all elements
		BorderPane pane = new BorderPane();
		pane.setStyle("-fx-background-color: #93D6FB");

		for(int i = 0; i < chatNames.getItems().size(); i++){
			System.out.println("CHAT NAMES: " + chatNames.getItems().get(i));
		}

		if(chatNames.getItems().isEmpty()){
			pane.setCenter(noChatMsg);
		}
		else{
			pane.setCenter(chatNames);
		}

		pane.setTop(bannerElements);

		// editing the fonts of the text
		noChatMsg.setFont(Font.font("Josefine Sans", FontWeight.BOLD, 32));
		noChatMsg.setTextAlignment(TextAlignment.CENTER);
		newChatMsg.setTextAlignment(TextAlignment.CENTER);
		newChatMsg.setFont(Font.font("Josefine Sans", FontWeight.NORMAL, 16));

		// handling the scene switching from the buttons
		viewUsers.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent actionEvent) {
				sceneMap.put("client", currentUsersScene(primaryStage, sceneMap));
				primaryStage.setScene(sceneMap.get("client"));
			}
		});

		createNewChat.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent actionEvent) {
				sceneMap.put("client", createNewChatScene(primaryStage, sceneMap));
				primaryStage.setScene(sceneMap.get("client"));
			}
		});

		return new Scene(pane, 500, 700);
	}

	public Scene currentUsersScene(Stage primaryStage, HashMap<String, Scene> sceneMap){
		Text title;
		Button back;
		ListView<String> namesListView;
		HBox bannerElements;

		// initializing the elements
		title = new Text("Current Users");
		back = new Button("BACK");
		bannerElements = new HBox(125, back, title);
		title.setFont(Font.font("Josefine Sans", FontWeight.BOLD, 24));

		// fill in names with actual implementation
		namesListView = usersList;

		// creating the border on top
		Rectangle banner = new Rectangle(500, 50);
		banner.setFill(Color.rgb(187, 217, 173));

		// adding elements on top of the banner
		StackPane bannerIcons = new StackPane();
		bannerElements.setAlignment(Pos.CENTER_LEFT);
		bannerIcons.getChildren().addAll(banner, bannerElements);

		// assigning elements to the borderpane
		BorderPane pane = new BorderPane();
		pane.setStyle("-fx-background-color: #93D6FB");
		pane.setTop(bannerIcons);
		pane.setCenter(namesListView);

		// assigning event handler
		back.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent actionEvent) {
				sceneMap.put("client", ActiveChatsScreen(primaryStage, sceneMap));
				primaryStage.setScene(sceneMap.get("client"));
			}
		});

		return new Scene(pane, 500, 700);
	}

	public Scene createNewChatScene(Stage primaryStage, HashMap<String, Scene> sceneMap) {
		Text title, enterUserText, enterChatNameText, usersAddedText;
		Button  addAllUsers, createNewChat, backButton;
		TextField enterUserPrompt, enterChatNamePrompt;
		ListView<String> namesListView;
		HBox bannerElements, enterUserElements, enterChatNameElements;
		VBox promptElements;

		// created drop down menu so the user can select who to direct message to
		ChoiceBox<String> userChatChoice = new ChoiceBox();

		for (int i = 0; i < clientConnection.msg.userNameList.size(); i++) {
			if (!clientConnection.msg.userNameList.get(i).equals(userName)) {
				userChatChoice.getItems().add(clientConnection.msg.userNameList.get(i));
			}
		}


		// initializing all the elements of the scene
		title = new Text("Create New Chat");
		enterUserText = new Text("              Enter User: ");
		enterChatNameText = new Text("Enter Chat Name: ");
		addAllUsers = new Button("ADD ALL USERS WITH CHAT");
		createNewChat = new Button("Create New Chat");
		enterUserPrompt = new TextField();
		enterChatNamePrompt = new TextField();
		backButton = new Button("BACK");
		bannerElements = new HBox(125, backButton, title);
		enterUserElements = new HBox(10, enterUserText, userChatChoice);
		enterChatNameElements = new HBox(10, enterChatNameText, enterChatNamePrompt);
		enterUserElements.setAlignment(Pos.CENTER);
		enterChatNameElements.setAlignment(Pos.CENTER);
		promptElements = new VBox(25, enterUserElements, enterChatNameElements, createNewChat);
		currentChatName = enterChatNamePrompt.getText();

		// creating the banner on top
		Rectangle banner = new Rectangle(500, 50);
		banner.setFill(Color.rgb(187, 217, 173));
		title.setFont(Font.font("Josefine Sans", FontWeight.BOLD, 24));

		// assigning the elements on the banner
		StackPane bannerIcons = new StackPane();
		bannerElements.setAlignment(Pos.CENTER_LEFT);
		bannerIcons.getChildren().addAll(banner, bannerElements);

		// aligning the pane elements
		BorderPane pane = new BorderPane();
		pane.setStyle("-fx-background-color: #93D6FB");
		pane.setTop(bannerIcons);
		pane.setCenter(promptElements);
		promptElements.setAlignment(Pos.CENTER);

		backButton.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent actionEvent) {
				sceneMap.put("client", ActiveChatsScreen(primaryStage, sceneMap));
				primaryStage.setScene(sceneMap.get("client"));
			}
		});

		if(clientConnection.msg.userNameList.size() <= 1){
			createNewChat.setDisable(true);
		}
		else{
			createNewChat.setDisable(false);
		}

		createNewChat.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent actionEvent) {
				msg.userNameToSend = userChatChoice.getValue().toString();
				userNameToSend2 = msg.userNameToSend;

				chatNames.getItems().add(new Button(enterChatNamePrompt.getText()));
				chatNames.getItems().getLast().setOnAction(new EventHandler<ActionEvent>() {
					@Override
					public void handle(ActionEvent actionEvent) {
						sceneMap.put("client", chatMessageScreen(primaryStage, sceneMap));
						primaryStage.setScene(sceneMap.get("client"));
					}
				});

				// create a new ListView and add that to an arrayList to display the designated ListView to a specific user?
				ListView newListView = new ListView();

				sceneMap.put("client", chatMessageScreen(primaryStage, sceneMap));
				primaryStage.setScene(sceneMap.get("client"));

			}
		});

		addAllUsers.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent actionEvent) {

				msg.directMessage = false;
				msg.chatToAll = true;

				chatNames.getItems().add(new Button(enterChatNamePrompt.getText()));
				chatNames.getItems().getLast().setOnAction(new EventHandler<ActionEvent>() {
					@Override
					public void handle(ActionEvent actionEvent) {
						sceneMap.put("client", chatMessageScreen(primaryStage, sceneMap));
						primaryStage.setScene(sceneMap.get("client"));
					}
				});

				sceneMap.put("client", chatMessageScreen(primaryStage, sceneMap));
				primaryStage.setScene(sceneMap.get("client"));
				// loop through the usernames and add them all to the chat
			}
		});

		return new Scene(pane, 500, 700);
	}

	public Scene chatMessageScreen(Stage primaryStage, HashMap<String, Scene> sceneMap){
		Button back, send, sendAll;
		Text chatName;
		TextField text;
		HBox bannerElements, sendMessageElements;

		text = new TextField();
		chatName = new Text("Message"); // should be changed to the group chat name
		back = new Button("BACK");
		send = new Button("SEND");
		sendAll = new Button("SEND ALL");

		bannerElements = new HBox(150, back, chatName);
		sendMessageElements = new HBox(text, send, sendAll);

		// creating the border on top
		Rectangle banner = new Rectangle(500, 50);
		banner.setFill(Color.rgb(187, 217, 173));

		// adding elements on top of the banner
		StackPane bannerIcons = new StackPane();
		bannerElements.setAlignment(Pos.CENTER_LEFT);
		bannerIcons.getChildren().addAll(banner, bannerElements);

		// assigning elements to the borderpane
		BorderPane pane = new BorderPane();
		pane.setStyle("-fx-background-color: #93D6FB");
		pane.setTop(bannerIcons);
		chatName.setFont(Font.font("Josefine Sans", FontWeight.BOLD, 24));

		text.setPrefWidth(375);
		sendMessageElements.setAlignment(Pos.BOTTOM_RIGHT);
		pane.setBottom(sendMessageElements);
		pane.setCenter(chatScreen);

		back.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent actionEvent) {
				sceneMap.put("client", ActiveChatsScreen(primaryStage, sceneMap));
				primaryStage.setScene(sceneMap.get("client"));
			}
		});

		send.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent actionEvent) {

				msg.textMessage = text.getText();
				msg.userName = userName;
				msg.userNameToSend = userNameToSend2;
				msg.directMessage = true;

				clientConnection.send(clientConnection.msg);

				text.clear();
			}
		});

		sendAll.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent actionEvent) {
				msg.textMessage = text.getText();
				msg.userName = userName;
				msg.userNameToSend = userNameToSend2;
				msg.chatToAll = true;

				clientConnection.send(clientConnection.msg);

				text.clear();
			}
		});


		return new Scene(pane, 500, 700);

	}


}
