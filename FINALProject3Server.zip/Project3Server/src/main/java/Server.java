import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Objects;
import java.util.function.Consumer;
//import static java.io.FileDescriptor.out;

//import com.sun.security.ntlm.Client;
import javafx.application.Platform;
import javafx.scene.control.ListView;
/*
 * Clicker: A: I really get it    B: No idea what you are talking about
 * C: kind of following
 */

public class Server{
	ArrayList<ClientThread> clients = new ArrayList<ClientThread>();
	ArrayList<String> userNames = new ArrayList<>();
	TheServer server;
	private Consumer<Serializable> callback;
	
	Server(Consumer<Serializable> call){
		callback = call;
		server = new TheServer();
		server.start();
	}
	
	
	public class TheServer extends Thread{
		
		public void run() {
		
			try(ServerSocket mysocket = new ServerSocket(5555);){
			
		    while(true) {
				ClientThread c = new ClientThread(mysocket.accept());

				clients.add(c);
				System.out.println("This is c: " + c);
				c.start();
			    }
			}//end of try
				catch(Exception e) {
					callback.accept("Server socket did not launch");
				}
			}//end of while
		}
	

		class ClientThread extends Thread{
			Socket connection;
			ObjectInputStream in;
			ObjectOutputStream out;
			Boolean loggedIn = false;
			String clientThreadUserName;
			String clientThreadUserNameToSend;

			ClientThread(Socket s){
				this.connection = s;
			}
			
			public void updateClients(Message message) {
				for(int i = 0; i < clients.size(); i++) {
					ClientThread t = clients.get(i);
					try {
						if(t.loggedIn) {
							t.out.writeObject(message);
						}
						else{
							Message tempMsg= new Message();
							tempMsg.userExists = true;
							tempMsg.userName = message.userName;
							t.out.writeObject(tempMsg);
						}
					}
					catch(Exception e) {}
				}
			}

			public void sendClient(Message message, String userToSend){

				for(int i = 0; i < clients.size(); i++){
					ClientThread t = clients.get(i);
					try{
						if (Objects.equals(t.clientThreadUserName, userToSend)) {
							t.out.writeObject(message);
						}
						if (Objects.equals(t.clientThreadUserName, clientThreadUserName)){
							t.out.writeObject(message);
						}
					}
					catch(Exception e){
						e.printStackTrace();
					}
				}
			}
			
			public void run(){
				try {
					in = new ObjectInputStream(connection.getInputStream());
					out = new ObjectOutputStream(connection.getOutputStream());
					connection.setTcpNoDelay(true);	
				}
				catch(Exception e) {
					System.out.println("Streams not open");
					e.printStackTrace();
				}

				 while(true) {
					    try {
					    	Message data = (Message) in.readObject();

							this.clientThreadUserName = data.userName;
							this.clientThreadUserNameToSend = data.userNameToSend;


							if(data.userName != null && data.directMessage == false && data.chatToAll == false) {
								for (int i = 0; i < userNames.size(); i++) {
									if (data.userName.equals(userNames.get(i))) {
										data.userExists = true;
										break;
									} else {
										data.userExists = false;
										break;
									}
								}

								// if the user does not already exist then we want to add the user to the list
								if (data.userExists == false) {
									callback.accept("client has connected to server with User Name: " + data.userName);
									userNames.add(data.userName);
									loggedIn = true;
								}

								//double-checking for no duplicate names
								for (int i = 0; i < userNames.size(); i++) {
									data.userNameList.add(userNames.get(i));
								}
								updateClients(data);
							}

							// UPDATING THE STUFF FOR THE SERVER GUI DIRECT MESSAGING
							if(data.textMessage != null && data.directMessage == true && data.chatToAll == false) {
								data.userExists = true;
								callback.accept(clientThreadUserName + " sent: " + data.textMessage);
								data.textMessage = clientThreadUserName + " sent: " + data.textMessage;
								// sending the data to data.userName
								data.directMessage = false;
								sendClient(data, clientThreadUserNameToSend);
							}
							else if(data.textMessage != null && data.chatToAll == true){
								data.userExists = true;
								callback.accept(clientThreadUserName + " sent to all users: " + data.textMessage);
								data.textMessage = clientThreadUserName + " sent to all users: " + data.textMessage;
								data.chatToAll = false;
								updateClients(data);
							}

					    	
					    	}
					    catch(Exception e) {
							e.printStackTrace();
					    	callback.accept("OOOOPPs...Something wrong with the socket from client: "  + "....closing down!");

							for(int i = 0; i < userNames.size(); i++){
								if(Objects.equals(clientThreadUserName, userNames.get(i))){
									userNames.remove(i);
									break;
								}
							}
					    	clients.remove(this);
					    	break;
					    }
					}
				}//end of run


			public void send(Message data) {
				try {
					out.writeObject(data);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
		}//end of client thread
}


	
	

	
