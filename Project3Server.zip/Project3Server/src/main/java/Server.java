import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.function.Consumer;

import javafx.application.Platform;
import javafx.scene.control.ListView;
/*
 * Clicker: A: I really get it    B: No idea what you are talking about
 * C: kind of following
 */

public class Server{
	ArrayList<ClientThread> clients = new ArrayList<ClientThread>();
	ArrayList<String> userNames = new ArrayList<>();
	TheServer server;
	private Consumer<Serializable> callback;
	String userName;
	
	Server(Consumer<Serializable> call){
		callback = call;
		server = new TheServer();
		server.start();
	}
	
	
	public class TheServer extends Thread{
		
		public void run() {
		
			try(ServerSocket mysocket = new ServerSocket(5555);){
		    System.out.println("Server is waiting for a client!");
		  
			
		    while(true) {
		
				ClientThread c = new ClientThread(mysocket.accept());

				// MOVE THIS TO SOMEWHERE ELSE
//				callback.accept("client has connected to server: " + "client #");
				/////////////////////////////

				clients.add(c);
				System.out.println("This is c: " + c);
				c.start();
			    }
			}//end of try
				catch(Exception e) {
					callback.accept("Server socket did not launch");
				}
			}//end of while
		}
	

		class ClientThread extends Thread{
			Socket connection;
			ObjectInputStream in;
			ObjectOutputStream out;
			String userName;
			Boolean userExists;
			Message message = new Message();

			ClientThread(Socket s){
				this.connection = s;
			}
			
			public void updateClients(String message) {
				for(int i = 0; i < clients.size(); i++) {
					ClientThread t = clients.get(i);
					try {
					 t.out.writeObject(message);
					}
					catch(Exception e) {}
				}
			}
			
			public void run(){
				try {
					in = new ObjectInputStream(connection.getInputStream());
					out = new ObjectOutputStream(connection.getOutputStream());
					connection.setTcpNoDelay(true);	
				}
				catch(Exception e) {
					System.out.println("Streams not open");
				}

				updateClients("new client on server: client #");
				System.out.println("new client on server");

				 while(true) {
					    try {
							System.out.println("INSIDE THE TRY STATEMENT");
					    	Message data = (Message) in.readObject();
							System.out.println("data is set to in.readObject()");

							//initiliaizng the message stuff

							message.setTextMessage(data.textMessage);
							System.out.println("setTextMessage is set to data");

							message.setUserName(data.userName);
//							System.out.println("setUserName is set to data.Username");

							System.out.println("This is data.textMessage: " + message.textMessage);
							System.out.println("This is data.userName: " + message.userName);


							// MOVING THE .ACCEPT THING HERE TESTING
							callback.accept("client has connected to server with User Name: " + message.userName);

							// UPDATING THE STUFF FOR THE GUI
					    	callback.accept("client: " +" sent: " + message.textMessage);
							
							// UPDATING THE SCREEN FOR THE CLIENTS
					    	updateClients("client #"+" said: "+data);
					    	
					    	}
					    catch(Exception e) {
					    	callback.accept("OOOOPPs...Something wrong with the socket from client: "  + "....closing down!");
					    	updateClients("Client #"+ " has left the server!");
					    	clients.remove(this);
					    	break;
					    }
					}
				}//end of run
			
			
		}//end of client thread
}


	
	

	
