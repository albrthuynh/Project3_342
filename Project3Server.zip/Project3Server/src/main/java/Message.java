import javafx.scene.control.ListView;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.function.Consumer;

public class Message implements Serializable {
    ArrayList<String> userNames;
    ListView<String> listOfUsers;
    String userName;
    String textMessage;
    static final long serialVersionUID = 42L;

    void setUserName(String userName) {
        this.userName = userName;
//        userNames.add(userName);
    }

    void setTextMessage(String text) {
        this.textMessage = text;
    }

    // would we add a username here???
    void addUsername (String userName) {
        userNames.add(userName);
    }

    ListView<String> getUsers() {
        return listOfUsers;
    }
}
