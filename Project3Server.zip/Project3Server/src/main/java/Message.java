import java.io.Serializable;
import java.util.ArrayList;
import java.util.function.Consumer;

public class Message implements Serializable {
    ArrayList<String> userNames;
    Server chat;
    private Consumer<Serializable> callback;
    static final long serialVersionUID = 42L;
}
