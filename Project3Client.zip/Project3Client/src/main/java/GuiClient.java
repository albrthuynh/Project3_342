
import java.util.HashMap;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

public class GuiClient extends Application{

	TextField c1;
	Button b1;
	HashMap<String, Scene> sceneMap;
	VBox clientBox;
	Client clientConnection;
	
	ListView<String> listItems2;
	
	
	public static void main(String[] args) {
		launch(args);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		clientConnection = new Client(data->{
				Platform.runLater(()->{listItems2.getItems().add(data.toString());
			});
		});
							
		clientConnection.start();

		listItems2 = new ListView<String>();
		
		c1 = new TextField();
		b1 = new Button("Send");
		b1.setOnAction(e->{clientConnection.send(c1.getText()); c1.clear();});
		
		sceneMap = new HashMap<String, Scene>();

//		sceneMap.put("client",  createClientGui());

		sceneMap.put("client",  welcomeScreen());

		
		primaryStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent t) {
                Platform.exit();
                System.exit(0);
            }
        });


		primaryStage.setScene(sceneMap.get("client"));
		primaryStage.setTitle("Client");
		primaryStage.setResizable(false);
		primaryStage.show();
		
	}

	public Scene createClientGui() {
		
		clientBox = new VBox(10, c1,b1,listItems2);
		clientBox.setStyle("-fx-background-color: blue;"+"-fx-font-family: 'serif';");
		return new Scene(clientBox, 400, 300);
		
	}

	public Scene welcomeScreen() {
		VBox welcomeScreenBox;
		HBox usernamePrompt;
		TextField inputUsername;
		Text title, enterUsername;
		Button startChattingButton;
		Image backgroundChatImage;

		// initializing the texts to their values
		title = new Text("WELCOME TO YAP!");
		startChattingButton = new Button("Start Chatting!");
		enterUsername = new Text("Enter Username: ");
		inputUsername = new TextField();

		// initializing the HBox and VBox values
		usernamePrompt = new HBox(10, enterUsername, inputUsername);
		welcomeScreenBox = new VBox(30, usernamePrompt, startChattingButton);
		BorderPane pane = new BorderPane();

		// creating the background with the borderpane
		backgroundChatImage = new Image("two_peeps_talking.png");
		BackgroundSize size = new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, false, false, true, false);
		Background background = new Background(new BackgroundImage(backgroundChatImage, BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER, size));
		pane.setBackground(background);

		// setting the alignments of all the elements
		pane.setTop(title);
		BorderPane.setAlignment(title, Pos.TOP_CENTER);
		pane.setBottom(welcomeScreenBox);
		welcomeScreenBox.setAlignment(Pos.BOTTOM_CENTER);
		startChattingButton.setAlignment(Pos.BOTTOM_CENTER);
		usernamePrompt.setAlignment(Pos.CENTER);
		enterUsername.setTextAlignment(TextAlignment.CENTER);
		pane.setPadding(new Insets(75));

		// setting the font sizes, font weight, and font of the text elements
		enterUsername.setFont(Font.font("Josefin Sans", FontWeight.NORMAL, 18));
		title.setFont(Font.font("Josefin Sans", FontWeight.BOLD, 30));
		inputUsername.setMinWidth(100);
		startChattingButton.setMinWidth(150);
		startChattingButton.setMinHeight(25);
		startChattingButton.setFont(Font.font("Josefine Sans", FontWeight.NORMAL, 18));
		startChattingButton.setStyle("-fx-background-color: #93D6FB");

		return new Scene(pane, 500, 700);
	}

}
