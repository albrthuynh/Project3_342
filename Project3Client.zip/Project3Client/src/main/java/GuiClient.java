
import java.util.HashMap;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

public class GuiClient extends Application{
	TextField c1;
	Button b1;
	HashMap<String, Scene> sceneMap;
	VBox clientBox;
	Client clientConnection;
	
	ListView<String> listItems2;
	
	
	public static void main(String[] args) {
		launch(args);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		clientConnection = new Client(data->{
				Platform.runLater(()->{listItems2.getItems().add(data.toString());
			});
		});
							
		clientConnection.start();

		listItems2 = new ListView<String>();
		
		c1 = new TextField();
		b1 = new Button("Send");
		b1.setOnAction(e->{clientConnection.send(c1.getText()); c1.clear();});
		
		sceneMap = new HashMap<String, Scene>();

//		sceneMap.put("client",  createClientGui());
		sceneMap.put("client",  welcomeScreen(primaryStage, sceneMap));
//		sceneMap.put("client", noActiveChatsScreen());
//		sceneMap.put("client", ActiveChatsScreen());
//		sceneMap.put("client", currentUsersScene(primaryStage, sceneMap));
//		sceneMap.put("client", createNewChatScene(primaryStage, sceneMap));
//		sceneMap.put("client", chatMessageScreen());


		primaryStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent t) {
                Platform.exit();
                System.exit(0);
            }
        });

		primaryStage.setScene(sceneMap.get("client"));
		primaryStage.setTitle("Client");
		primaryStage.setResizable(false);
		primaryStage.show();
	}

	public Scene createClientGui() {
		clientBox = new VBox(10, c1,b1,listItems2);
		clientBox.setStyle("-fx-background-color: blue;"+"-fx-font-family: 'serif';");
		return new Scene(clientBox, 400, 300);
	}

	public Scene welcomeScreen(Stage primaryStage, HashMap<String, Scene> sceneMap) {
		VBox welcomeScreenBox;
		HBox usernamePrompt;
		TextField inputUsername;
		Text title, enterUsername;
		Button startChattingButton;
		Image backgroundChatImage;

		// initializing the texts to their values
		title = new Text("WELCOME TO YAP!");
		startChattingButton = new Button("Start Chatting!");
		enterUsername = new Text("Enter Username: ");
		inputUsername = new TextField();

		// initializing the HBox and VBox values
		usernamePrompt = new HBox(10, enterUsername, inputUsername);
		welcomeScreenBox = new VBox(30, usernamePrompt, startChattingButton);
		BorderPane pane = new BorderPane();

		// creating the background with the borderpane
		backgroundChatImage = new Image("two_peeps_talking.png");
		BackgroundSize size = new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, false, false, true, false);
		Background background = new Background(new BackgroundImage(backgroundChatImage, BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER, size));
		pane.setBackground(background);

		// setting the alignments of all the elements
		pane.setTop(title);
		BorderPane.setAlignment(title, Pos.TOP_CENTER);
		pane.setBottom(welcomeScreenBox);
		welcomeScreenBox.setAlignment(Pos.BOTTOM_CENTER);
		startChattingButton.setAlignment(Pos.BOTTOM_CENTER);
		usernamePrompt.setAlignment(Pos.CENTER);
		enterUsername.setTextAlignment(TextAlignment.CENTER);
		pane.setPadding(new Insets(75));

		// setting the font sizes, font weight, and font of the text elements
		enterUsername.setFont(Font.font("Josefin Sans", FontWeight.NORMAL, 18));
		title.setFont(Font.font("Josefin Sans", FontWeight.BOLD, 30));
		inputUsername.setMinWidth(100);
		startChattingButton.setMinWidth(150);
		startChattingButton.setMinHeight(25);
		startChattingButton.setFont(Font.font("Josefine Sans", FontWeight.NORMAL, 18));
		startChattingButton.setStyle("-fx-background-color: #93D6FB");

		// handle what happens when there is nothing inside the text field
		startChattingButton.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent actionEvent) {
				sceneMap.put("client", noActiveChatsScreen(primaryStage, sceneMap));
				primaryStage.setScene(sceneMap.get("client"));
			}
		});

		return new Scene(pane, 500, 700);
	}

	public Scene noActiveChatsScreen(Stage primaryStage, HashMap<String, Scene> sceneMap){
		Text newChatMsg, noChatMsg;
		Image personIcon, plusIcon;
		Button viewUsers, createNewChat;
		ImageView personIconView, plusIconView;
		HBox createNewChatIcons, bannerIcons;

		// initializing the elements
		newChatMsg = new Text("Create New Chat");
		noChatMsg = new Text("No Active chats! Create a new chat\nto get the conversation going :)");
		personIcon = new Image("png_gruopchat.png");
		plusIcon = new Image("icon_plus_proj3.png");
		viewUsers = new Button();
		createNewChat = new Button();
		personIconView = new ImageView(personIcon);
		plusIconView = new ImageView(plusIcon);
		viewUsers.setGraphic(personIconView);
		createNewChat.setGraphic(plusIconView);
		createNewChatIcons = new HBox(10, newChatMsg, createNewChat);
		createNewChatIcons.setAlignment(Pos.CENTER);
		bannerIcons = new HBox(275, viewUsers, createNewChatIcons);
		bannerIcons.setAlignment(Pos.CENTER);

		// styling the top with a banner
		Rectangle banner = new Rectangle(500, 50);
		banner.setFill(Color.rgb(187, 217, 173));

		// adding elements to the banner
		StackPane bannerElements = new StackPane();
		bannerElements.getChildren().addAll(banner, bannerIcons);

		// editing the images to fit the screen
		personIconView.setPreserveRatio(true);
		personIconView.setFitHeight(25);
		personIconView.setFitWidth(25);
		plusIconView.setPreserveRatio(true);
		plusIconView.setFitHeight(25);
		plusIconView.setFitHeight(25);

		// creating border pane and aligning + setting all elements
		BorderPane pane = new BorderPane();
		pane.setStyle("-fx-background-color: #93D6FB");
		pane.setCenter(noChatMsg);
		pane.setTop(bannerElements);

		// editing the fonts of the text
		noChatMsg.setFont(Font.font("Josefine Sans", FontWeight.BOLD, 32));
		noChatMsg.setTextAlignment(TextAlignment.CENTER);
		newChatMsg.setTextAlignment(TextAlignment.CENTER);
		newChatMsg.setFont(Font.font("Josefine Sans", FontWeight.NORMAL, 16));

		// handling the scene switching from the buttons
		viewUsers.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent actionEvent) {
				sceneMap.put("client", currentUsersScene(primaryStage, sceneMap));
				primaryStage.setScene(sceneMap.get("client"));
			}
		});

		createNewChat.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent actionEvent) {
				sceneMap.put("client", createNewChatScene(primaryStage, sceneMap));
				primaryStage.setScene(sceneMap.get("client"));
			}
		});

		return new Scene(pane, 500, 700);
	}

	public Scene ActiveChatsScreen(Stage primaryStage, HashMap<String, Scene> sceneMap){
		Text newChatMsg;
		Image personIcon, plusIcon;
		Button viewUsers, createNewChat;
		ImageView personIconView, plusIconView;
		HBox createNewChatIcons, bannerIcons;

		// initializing the elements
		newChatMsg = new Text("Create New Chat");
		personIcon = new Image("png_gruopchat.png");
		plusIcon = new Image("icon_plus_proj3.png");
		viewUsers = new Button();
		createNewChat = new Button();
		personIconView = new ImageView(personIcon);
		plusIconView = new ImageView(plusIcon);
		viewUsers.setGraphic(personIconView);
		createNewChat.setGraphic(plusIconView);
		createNewChatIcons = new HBox(10, newChatMsg, createNewChat);
		createNewChatIcons.setAlignment(Pos.CENTER);
		bannerIcons = new HBox(275, viewUsers, createNewChatIcons);
		bannerIcons.setAlignment(Pos.CENTER);

		// styling the top with a banner
		Rectangle banner = new Rectangle(500, 50);
		banner.setFill(Color.rgb(187, 217, 173));

		// adding elements to the banner
		StackPane bannerElements = new StackPane();
		bannerElements.getChildren().addAll(banner, bannerIcons);

		// editing the images to fit the screen
		personIconView.setPreserveRatio(true);
		personIconView.setFitHeight(25);
		personIconView.setFitWidth(25);
		plusIconView.setPreserveRatio(true);
		plusIconView.setFitHeight(25);
		plusIconView.setFitHeight(25);

		// creating border pane and aligning + setting all elements
		BorderPane pane = new BorderPane();
		pane.setStyle("-fx-background-color: #93D6FB");
		pane.setTop(bannerElements);

		// TESTING THE LIST VIEW
		// would have to figure out with the backend how to get all the users names, (automatically does the scrolling feature)
		ObservableList<String> names = FXCollections.observableArrayList("Engineering", "MCA", "MBA", "Graduation", "MTECH", "Mphil", "Phd", "a", "b", "c","a", "b", "c","a", "b", "c","a", "b", "c","a", "b", "c","a", "b", "c","a", "b", "c","a", "b", "c","a", "b", "c","a", "b", "c","a", "b", "c","a", "b", "c");
		ListView<String> listView = new ListView<String>(names);
		pane.setCenter(listView);
		/////////////////////////////////

		// editing the fonts of the text
		newChatMsg.setTextAlignment(TextAlignment.CENTER);
		newChatMsg.setFont(Font.font("Josefine Sans", FontWeight.NORMAL, 16));

		return new Scene(pane, 500, 700);
	}

	public Scene currentUsersScene(Stage primaryStage, HashMap<String, Scene> sceneMap){
		Text title;
		Button back;
		ListView<String> namesListView;
		HBox bannerElements;

		// initializing the elements
		title = new Text("Current Users");
		back = new Button("BACK");
		bannerElements = new HBox(125, back, title);
		title.setFont(Font.font("Josefine Sans", FontWeight.BOLD, 24));

		//EXAMPLE ONLY
		ObservableList<String> names = FXCollections.observableArrayList("Engineering", "MCA", "MBA", "Graduation", "MTECH", "Mphil", "Phd", "a", "b", "c","a", "b", "c","a", "b", "c","a", "b", "c","a", "b", "c","a", "b", "c","a", "b", "c","a", "b", "c","a", "b", "c","a", "b", "c","a", "b", "c","a", "b", "c");
		///////////////

		// fill in names with actual implementation
		namesListView = new ListView<>(names);


		// creating the border on top
		Rectangle banner = new Rectangle(500, 50);
		banner.setFill(Color.rgb(187, 217, 173));

		// adding elements on top of the banner
		StackPane bannerIcons = new StackPane();
		bannerElements.setAlignment(Pos.CENTER_LEFT);
		bannerIcons.getChildren().addAll(banner, bannerElements);

		// assigning elements to the borderpane
		BorderPane pane = new BorderPane();
		pane.setStyle("-fx-background-color: #93D6FB");
		pane.setTop(bannerIcons);
		pane.setCenter(namesListView);

		// assigning event handler
		back.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent actionEvent) {
				sceneMap.put("client", noActiveChatsScreen(primaryStage, sceneMap));
				primaryStage.setScene(sceneMap.get("client"));
			}
		});

		return new Scene(pane, 500, 700);
	}

	public Scene createNewChatScene(Stage primaryStage, HashMap<String, Scene> sceneMap) {
		Text title, enterUserText, enterChatNameText, usersAddedText;
		Button  addAllUsers, createNewChat, backButton;
		TextField enterUserPrompt, enterChatNamePrompt;
		ListView<String> namesListView;
		HBox bannerElements, enterUserElements, enterChatNameElements;
		VBox promptElements;

		// initializing all the elements of the scene
		title = new Text("Create New Chat");
		enterUserText = new Text("              Enter User: ");
		enterChatNameText = new Text("Enter Chat Name: ");
		usersAddedText = new Text("Users To Be Added");
		addAllUsers = new Button("ADD ALL USERS WITH CHAT");
		createNewChat = new Button("Create New Chat");
		enterUserPrompt = new TextField();
		enterChatNamePrompt = new TextField();
		backButton = new Button("BACK");
		bannerElements = new HBox(125, backButton, title);
		enterUserElements = new HBox(10, enterUserText, enterUserPrompt);
		enterChatNameElements = new HBox(10, enterChatNameText, enterChatNamePrompt);
		enterUserElements.setAlignment(Pos.CENTER);
		enterChatNameElements.setAlignment(Pos.CENTER);
		promptElements = new VBox(25, enterUserElements, enterChatNameElements, createNewChat, addAllUsers);

		// creating the banner on top
		Rectangle banner = new Rectangle(500, 50);
		banner.setFill(Color.rgb(187, 217, 173));
		title.setFont(Font.font("Josefine Sans", FontWeight.BOLD, 24));

		// assigning the elements on the banner
		StackPane bannerIcons = new StackPane();
		bannerElements.setAlignment(Pos.CENTER_LEFT);
		bannerIcons.getChildren().addAll(banner, bannerElements);

		// aligning the pane elements
		BorderPane pane = new BorderPane();
		pane.setStyle("-fx-background-color: #93D6FB");
		pane.setTop(bannerIcons);
		pane.setCenter(promptElements);
		promptElements.setAlignment(Pos.CENTER);

		backButton.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent actionEvent) {
				sceneMap.put("client", noActiveChatsScreen(primaryStage, sceneMap));
				primaryStage.setScene(sceneMap.get("client"));
			}
		});

		createNewChat.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent actionEvent) {
				sceneMap.put("client", chatMessageScreen(primaryStage, sceneMap));
				primaryStage.setScene(sceneMap.get("client"));
			}
		});

		addAllUsers.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent actionEvent) {
				sceneMap.put("client", chatMessageScreen(primaryStage, sceneMap));
				primaryStage.setScene(sceneMap.get("client"));
			}
		});

		return new Scene(pane, 500, 700);
	}

	public Scene chatMessageScreen(Stage primaryStage, HashMap<String, Scene> sceneMap){
		Button back, send;
		Text chatName;
		TextField text;
		HBox bannerElements, sendMessageElements;

		text = new TextField();
		chatName = new Text("Current Users"); // should be changed to the group chat name
		back = new Button("BACK");
		send = new Button("SEND");

		bannerElements = new HBox(125, back, chatName);
		sendMessageElements = new HBox(text, send);

		// creating the border on top
		Rectangle banner = new Rectangle(500, 50);
		banner.setFill(Color.rgb(187, 217, 173));

		// adding elements on top of the banner
		StackPane bannerIcons = new StackPane();
		bannerElements.setAlignment(Pos.CENTER_LEFT);
		bannerIcons.getChildren().addAll(banner, bannerElements);

		// assigning elements to the borderpane
		BorderPane pane = new BorderPane();
		pane.setStyle("-fx-background-color: #93D6FB");
		pane.setTop(bannerIcons);
		chatName.setFont(Font.font("Josefine Sans", FontWeight.BOLD, 24));

		text.setPrefWidth(450);
		sendMessageElements.setAlignment(Pos.BOTTOM_RIGHT);
		pane.setBottom(sendMessageElements);

		back.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent actionEvent) {
				sceneMap.put("client", noActiveChatsScreen(primaryStage, sceneMap));
				primaryStage.setScene(sceneMap.get("client"));
			}
		});


		// NEED TO ADD A WAY TO DISPLAY ALL THE MESSAGES BEING SENT (like an array)

		return new Scene(pane, 500, 700);

	}


}
