import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Objects;
import java.util.function.Consumer;
//import static java.io.FileDescriptor.out;

//import com.sun.security.ntlm.Client;
import javafx.application.Platform;
import javafx.scene.control.ListView;
/*
 * Clicker: A: I really get it    B: No idea what you are talking about
 * C: kind of following
 */

public class Server{
	ArrayList<ClientThread> clients = new ArrayList<ClientThread>();
	ArrayList<String> userNames = new ArrayList<>();
	TheServer server;
	private Consumer<Serializable> callback;
	
	Server(Consumer<Serializable> call){
		callback = call;
		server = new TheServer();
		server.start();
	}
	
	
	public class TheServer extends Thread{
		
		public void run() {
		
			try(ServerSocket mysocket = new ServerSocket(5555);){
		    System.out.println("Server is waiting for a client!");
		  
			
		    while(true) {
				ClientThread c = new ClientThread(mysocket.accept());

				// MOVE THIS TO SOMEWHERE ELSE
//				callback.accept("client has connected to server: " + "client #");
				/////////////////////////////

				clients.add(c);
				System.out.println("This is c: " + c);
				c.start();
			    }
			}//end of try
				catch(Exception e) {
					callback.accept("Server socket did not launch");
				}
			}//end of while
		}
	

		class ClientThread extends Thread{
			Socket connection;
			ObjectInputStream in;
			ObjectOutputStream out;
			Boolean loggedIn = false;
			String clientThreadUserName;
			String clientThreadUserNameToSend;

			// lets see if not having this is okay
//			Message message = new Message();

			ClientThread(Socket s){
				this.connection = s;
			}
			
			public void updateClients(Message message) {
				System.out.println("Printing to everyone! and updating users too!");
				for(int i = 0; i < clients.size(); i++) {
					ClientThread t = clients.get(i);
					try {
//						t.out.reset();
						System.out.println("this is t.loggedIn for " + t.clientThreadUserName + " " + t.loggedIn);
						if(t.loggedIn) {
							t.out.writeObject(message);
						}
					}
					catch(Exception e) {}
				}
			}

			public void sendClient(Message message, String userToSend){
				for(int i = 0; i < clients.size(); i++){
					System.out.println("CLIENT THREAD USERNAME " + i + clients.get(i).clientThreadUserName);
				}

				for(int i = 0; i < clients.size(); i++){
					ClientThread t = clients.get(i);
					try{
						if (Objects.equals(t.clientThreadUserName, userToSend)) {
							System.out.println("Trying to print to individual");
							t.out.writeObject(message);
						}
						if (Objects.equals(t.clientThreadUserName, clientThreadUserName)){
							t.out.writeObject(message);
						}
					}
					catch(Exception e){
						e.printStackTrace();
					}
				}
			}
			
			public void run(){
				try {
					in = new ObjectInputStream(connection.getInputStream());
					out = new ObjectOutputStream(connection.getOutputStream());
					connection.setTcpNoDelay(true);	
				}
				catch(Exception e) {
					System.out.println("Streams not open");
				}

//				updateClients("new client on server: client #");
//				System.out.println("new client on server");

				 while(true) {
					    try {
							// waits until the button is pressed again
							System.out.println("INSIDE THE TRY STATEMENT");

					    	Message data = (Message) in.readObject();

							System.out.println("This is the data userName reading in: " + data.userName);
							System.out.println("This is the data userNameToSend reading in: " + data.userNameToSend);

							this.clientThreadUserName = data.userName;
							this.clientThreadUserNameToSend = data.userNameToSend;

							System.out.println("This is the clientThreadUserName: " + this.clientThreadUserName);
							System.out.println("This is the clientThreadUserNameToSend: " + this.clientThreadUserNameToSend);

							//printing out all the threads names
							for(int i = 0; i < clients.size(); i++) {
								ClientThread t = clients.get(i);
								try {
									System.out.println("Thread username is at index: " + i + " " + t.clientThreadUserName);
								}
								catch(Exception e) {}
							}



							if(data.userName != null && data.directMessage == false) {
								System.out.println("USERNAME: " + data.userName);
								for (int i = 0; i < userNames.size(); i++) {
									if (data.userName.equals(userNames.get(i))) {
										System.out.println("THERE IS A USER THAT IS EXISTING ALREADY IN THE LIST");
										data.userExists = true;
										break;
									} else {
										System.out.println("the username is unique");
										data.userExists = false;
										break;
									}
								}

								// MOVING THE .ACCEPT THING HERE TESTING

								// if the user does not already exist then we want to add the user to the list
								if (data.userExists == false) {
									System.out.println("client has connected to server with username: " + data.userName);
									callback.accept("client has connected to server with User Name: " + data.userName);
									userNames.add(data.userName);
									loggedIn = true;
//									updateClients(data);
								}

								//double checking for no duplicate names
								for (int i = 0; i < userNames.size(); i++) {
									data.userNameList.add(userNames.get(i));
								}

								for(int i = 0; i < data.userNameList.size(); i++){
									System.out.println("data.userNameList index at: " + i + " " + data.userNameList.get(i));
								}

								updateClients(data);
							}

							// UPDATING THE STUFF FOR THE SERVER GUI DIRECT MESSAGING
							if(data.textMessage != null && data.directMessage == true) {
								data.userExists = true;
								callback.accept(clientThreadUserName + " sent: " + data.textMessage);
								data.textMessage = clientThreadUserName + " sent: " + data.textMessage;
								// sending the data to data.userName
								System.out.println("userNameToSend is: " + clientThreadUserNameToSend);
								sendClient(data, clientThreadUserNameToSend);
							}
							else if(data.textMessage != null && data.chatToAll == true){
								data.userExists = true;
								callback.accept(clientThreadUserName + " sent to all users: " + data.textMessage);
								data.textMessage = clientThreadUserName + " sent to all users: " + data.textMessage;

								for(int i = 0; i < clients.size(); i++){
									sendClient(data, clients.get(i).clientThreadUserName);
								}
							}
							else{
								System.out.println("The data.textMessage is: " + data.textMessage);
							}
					    	
					    	}
					    catch(Exception e) {
							e.printStackTrace();
					    	callback.accept("OOOOPPs...Something wrong with the socket from client: "  + "....closing down!");
//					    	updateClients("Client #"+ " has left the server!");

							for(int i = 0; i < userNames.size(); i++){
								if(Objects.equals(clientThreadUserName, userNames.get(i))){
									userNames.remove(i);
									System.out.println("REMOVING THIS NAME: " + userNames.get(i));
									break;
								}
							}

					    	clients.remove(this);
					    	break;
					    }
					}
				}//end of run


			public void send(Message data) {
				try {
					out.writeObject(data);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
		}//end of client thread
}


	
	

	
