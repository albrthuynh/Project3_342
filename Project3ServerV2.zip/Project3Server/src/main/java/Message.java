import javafx.scene.control.ListView;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.function.Consumer;

public class Message implements Serializable {
    ArrayList<String> userNameList = new ArrayList<>();

    String userName;
    String textMessage;
    int numOfUsers = 0;
    Boolean userExists = false;
    static final long serialVersionUID = 42L;

    void setUserName(String userName) {
        this.userName = userName;
    }

    void setTextMessage(String text) {
        this.textMessage = text;
    }

//    ListView<String> getUsers() {
//        return listOfUsers;
//    }

    void addUser(String user) {
        userNameList.add(user);
        numOfUsers++;
    }

    void setUserExists(Boolean bool){
        userExists = bool;
    }

    Boolean getUserExists(){
        return userExists;
    }
}
